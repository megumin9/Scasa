=================
Canalyze Checkers
=================

The checkers transferred from Canalyze and newly added.

.. contents:: Table of Contents
   :depth: 4


.. _canalyze-checkers:

canalyze
^^^^^^^^
Checkers transferred or re-implemented based on the corresponding vanilla checkers in Canalyze, which are not available in CSA.
For some checkers, the functionalities are slightly changed or extended.

.. _canalyze-DivOverflow:

canalyze.DivOverflow [D202] (C, C++)
""""""""""""""""""""""""""""""""""""
* Canalyze bug ID: D202
* Canalyze implementation: core/lib/Checkers/DivZeroChecker.cpp

Check for divisions that min value divided by -1.
If the quotient ``a / b`` is not representable in the result type, the behavior of both ``a / b`` and ``a % b`` is undefined.
(Refer to: `cppreference - Arithmetic Operators - Multiplicative Operators`__).
Usually, this bug will lead to a crash.

__ <https://en.cppreference.com/w/cpp/language/operator_arithmetic#Multiplicative_operators>

If the dividend is the min value of its type, and the divisor is -1, then report the bug.
If the dividend is the min value of its type, and the divisor is a symbolic value, then add the constraint "divisor is not -1".
If the dividend is a symbolic value, and the divisor is -1, then add the constraint "divisor is not the min value of its type".

.. code-block:: c

 #include <limits.h>

 int f() {
   int x = INT_MIN;
   int y = -1;
   return x / y;  // warn
 }

**Note**: Some compilers have optimization on constant value arithmetic expressions,
which will not trigger a crash if both dividend and divisor are constant.
