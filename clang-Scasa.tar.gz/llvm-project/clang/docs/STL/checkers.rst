============
STL Checkers
============

The checkers point to STL.

.. contents:: Table of Contents
   :depth: 4


.. _STL-checkers:

STL
^^^
Checkers point to STL.

.. _STL-ForEachN:

STL.ForEachN [2-1] (C++)
""""""""""""""""""""""""
* STL bug ID: 2-1
* STL implementation: core/lib/Checkers/ForEachNChecker.cpp

When using for_each_n, n should not less than 0.

If n is less than 0, then report the bug.
If not, add the transition that n is not less than 0.

.. code-block:: c

 #include <algorithm>

 void f() {
   std::for_each_n(*p, -1, g);  // warn
 }

**Note**: n < 0 will cause an undefined behavior.

.. _STL-CopyRange:

STL.CopyRange [2-2] (C++)
"""""""""""""""""""""""""
* STL bug ID: 2-2
* STL implementation: core/lib/Checkers/CopyRangeChecker.cpp

When using copy_range, the begin iterator of destination should not be within [first,last) of the source range.

If the begin iterator of destination is within [first,last), then report the bug.

.. code-block:: c

 #include <algorithm>

 void f() {
   vector<int> v{1,2,3,4,5};
   std::copy(v.begin(),v.end(),v.begin()+1);  // warn
 }

**Note**: it will cause an undefined behavior.

.. _STL-Clamp:

STL.Clamp [2-3] (C++)
"""""""""""""""""""""
* STL bug ID: 2-3
* STL implementation: core/lib/Checkers/ClampChecker.cpp

When using clamp, lo should not bigger than hi.

If lo is bigger than hi, then report the bug.
If not, add the transition that lo is not bigger than hi, and the return value is between lo and hi.

.. code-block:: c

 #include <algorithm>

 int f(int x, int y) {
   int z = 0;
   if(x > y)
     z = std::clamp(0, x, y);  // warn
   return z;
 }

**Note**: lo > hi will cause an undefined behavior.

.. _STL-UnorderedEqual:

STL.UnorderedEqual [2-4] (C++)
""""""""""""""""""""""""""""""
* STL bug ID: 2-4
* STL implementation: core/lib/Checkers/UnorderedEqualChecker.cpp

Using std::equal to compare between unordered containers might get an incorrect result.

If one of the argument iterator is from an unordered container, then report the bug.

.. code-block:: c

 #include <algorithm>

 int f(int x, int y) {
   set<int> s{1,2,3};
   unordered_set<int> us{1,2,3};
   std::equal(s.begin(),s.end(),us.begin());  //warn
 }

**Note**: It will not cause an undefined behavior, but the result will usually be false.
