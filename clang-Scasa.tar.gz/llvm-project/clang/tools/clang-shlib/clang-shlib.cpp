// Intentionally empty source file to make CMake happy
