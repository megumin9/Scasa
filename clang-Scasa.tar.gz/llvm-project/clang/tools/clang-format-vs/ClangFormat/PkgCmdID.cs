﻿namespace LLVM.ClangFormat
{
    static class PkgCmdIDList
    {
        public const uint cmdidClangFormatSelection = 0x100;
        public const uint cmdidClangFormatDocument = 0x101;
    };
}
